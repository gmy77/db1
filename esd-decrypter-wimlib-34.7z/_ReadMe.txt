===============================================================================
# Info #

An automated script to process Microsoft's original ESD file (encrypted or decrypted),
to convert it into a usable state (ISO / WIM / decrypted ESD).

===============================================================================
# Attention #

- Administrator privileges are required to run the script

- The script is set to not backup encrypted ESD before decrypting it, which will change the file hash
if you want to maintain the original file state, turn the backup ON by pressing 9 before proceeding to other operations.

===============================================================================
# How To Use #

- Temporary disable AV or protection program so it doesn't interfere with the process.

- Make sure the ESD file is not read-only or blocked.

- Extract this pack to a folder with simple path to avoid troubles (example: C:\ESD).

- You may start the process using any of these ways:
# Copy/Move ESD file to the same folder besides the script, then run decrypt.cmd

# Drag & drop ESD file on decrypt.cmd

# Directly run decrypt.cmd and you will be prompted to enter the ESD file path

# Open Admin Command Prompt in the current directory, and Execute: decrypt ESDFileNameAndPath
examples:
decrypt 15063.0.170317-1834.rs2_release_cliententerprise_vol_x86fre_en-us_dc818e39982d8bd922dca73fd51e330aa99bc3f1.esd
decrypt C:\RecoveryImage\install.esd
decrypt H:\ESD\ir4_cpra_x64frer_en-us.esd

===============================================================================
# Multi Editions ESD Options #

If the choosen ESD contains multiple editions, you will get these options:
1 - Continue including all editions
2 - Include one edition
3 - Include consecutive range of editions
4 - Include randomly selected editions

To disable this menu and go to main menu directly,
edit the script and change "SET MultiChoice=1" to "SET MultiChoice=0"

===============================================================================
# Main Menu Options #

1 - Create Full ISO with Standard install.wim
this will convert ESD to a regular ISO distribution that contains standard install.wim

2 - Create Full ISO with Compressed install.esd
similar to the first, but it will have highly compressed install.esd

3 - Create Standard install.wim
this will only create install.wim, which can be used with other ISO for the same product version
or to use it for manual apply using dism/wimlib

4 - Create Compressed install.esd
similar to the third, but it will create install.esd file, which can be used just like install.wim

5 - Decrypt ESD file only (if the file is encrypted)

5 - ESD file info (if the file is not encrypted)

===============================================================================
# Multi-Architecture ISO (x86/x64) #

It is possible to create an ISO for both architectures together, similar to Media Creation Tool

How to:
- get 2 ESDs with different architectures, same language, same version (i.e. both en-us build 10586)
- place the ESD files next to the script
- execute the script directly, and choose an option that suites you

Options:
1- ISO with 2 solid install.esd                 (same as MediaCreationTool)
this will create two separate install.esd for each architecture

2- ISO with 2 serviceable install.wim           (similar to 1, bigger size)
this will create two separate install.wim for each architecture

3- ISO with 1 shared serviceable install.wim         (smaller overall size)
this will combine both architectures images into one install.wim, which will be duplicated in each architecture directory,
then, ISO optimization feature is used to reduce the overall size by storing it once (shared file)

===============================================================================
# Notice #

If ESD decryption fails, run update_esd_cryptokey_data.cmd to get the latest key database
specially if a new build is released with new ESD Decryption Key

===============================================================================
# Credits #

qad
esddecrypt.exe program

@tfwboredom
new key support for esddecrypt.exe

Eric Biggers
wimlib

mkuba50
busybox method to help create identical ISO from the same ESD

@rgadguard
RSA cryptokeys key.cmd host server / update script

RSA cryptokeys
MrMagic, Chris123NT, mohitbajaj143, Superwzt, timster

murphy78
original script

nosferati87, NiFu, s1ave77, ztsoft, and any other MDL forums members contributed in the ESD project

===============================================================================