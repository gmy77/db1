================================================================
# KMS_VL_ALL.cmd #

Activate supported products. No installation or schedule tasks will be created.

You will need to run it again before the activation period expire (6 months default).

================================================================
# Create-Remove-Task.cmd #

Install the project and create scheduled reactivation task.

You can also use it to remove installed project and its tasks.

You can change Daily/Weekly/Monthly tasks start time/day after creation via Task Scheduler 

For advanced users, you can edit the tasks .xml files in Win32 folder

================================================================
# Notes #

Remove any other KMS solutions. Temporary turn off AV security protection. Run as administrator.

Some security programs will report the file infected, that is false-positive due KMS emulating.

If you installed the project for reactivation, exclude this folder in your security protection:
"C:\Windows\KMS_VL_ALL"

================================================================
# Supported Volume Products #

Windows 7/8/8.1/10
Windows Server 2008R2/2012/2012R2/2016
Office 2010/2013/2016

================================================================
# Credits #

Hotbird64      - vlmcsd KMS Emulator
mishamosherg   - FakeClient for WinDivert 1.1.8
MasterDisaster - initial activation script / WMI methods
qewpal         - KMS_VL_ALL author
abbodi1406     - KMS_VL_ALL-WinDivert-kms author
