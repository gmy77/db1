================================================================
# To install this solution for auto renewal activation, run these scripts respectively:

1-SppExtComObjPatcher.cmd
install/uninstall the Patcher Hook.

2-Activate-Local.cmd
activate installed supported products. (you must run it at least once).
you may need to run it again if you installed Office product afterwards.

================================================================
# To just activate without installing and without renewal, run this script only:

KMS_VL_ALL.cmd

you will need to run it again before the activation period expire (6 months default).

================================================================
# Notes:

- Some security programs will report the file infected, that is false-positive due KMS emulating.
- Remove any other KMS solutions. Temporary turn off AV security protection. Run as administrator.
- If you installed the solution for auto renewal, exclude these two files in AV security protection:
%windir%\system32\SppExtComObjPatcher.exe
%windir%\system32\SppExtComObjHook.dll

================================================================
# Bonus:

- To preactivate the system during installation, copy $oem$ to "sources" folder in the installation media (iso/usb)

- if you already use another setupcomplete.cmd, rename this one to KMS_VL_ALL.cmd or similar name
then add a command to run it in your setupcomplete.cmd, example:
call KMS_VL_ALL.cmd

- use SppExtComObjPatcher.cmd if you want to uninstall the project afterwards.

- note: setupcomplete.cmd is disabled if the default installed key for the edition is OEM Channel

================================================================
# Supported Volume Products:

Windows 7/8/8.1/10
Windows Server 2008R2/2012/2012R2/2016
Office 2010/2013/2016

================================================================
# Credits

qad            - SppExtComObjPatcher
MasterDisaster - initial script / WMI methods
qewpal         - KMS_VL_ALL author
Nucleus        - special assistance
Enthousiast    - special assistance
abbodi1406     - KMS_VL_ALL-SppExtComObjPatcher-kms author
